// Service worker: candidates ko ek-ek karke try karta hai aur pehla jo chal jaye usse save karta hai.
// (HEAD check ki jagah seedha download try karte hain - zyada reliable hai.)

function bumpCounter() {
  chrome.storage.local.get({ count: 0 }, ({ count }) =>
    chrome.storage.local.set({ count: count + 1 }));
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "PINSAVER_BUMP") { bumpCounter(); return; }
  if (msg && msg.type === "PINSAVER_DOWNLOAD") {
    handleDownload(msg)
      .then(sendResponse)
      .catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true; // async response
  }
});

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function extensionOf(url, kind) {
  try {
    const m = new URL(url).pathname.match(/\.(jpe?g|png|gif|webp|mp4)$/i);
    if (m) return m[1].toLowerCase();
  } catch (_) {}
  return kind === "video" ? "mp4" : "jpg";
}

async function attemptDownload(url, filename) {
  let dlId;
  try {
    dlId = await chrome.downloads.download({
      url, filename, conflictAction: "uniquify", saveAs: false
    });
  } catch (_) {
    return false;
  }
  const started = Date.now();
  while (Date.now() - started < 20000) {
    const [item] = await chrome.downloads.search({ id: dlId });
    if (!item) return false;
    if (item.state === "interrupted") {       // 404/403 etc.
      chrome.downloads.erase({ id: dlId });
      return false;
    }
    if (item.state === "complete" || item.bytesReceived > 0) return true;
    await sleep(250);
  }
  return true; // slow server, par fail nahi hua
}

async function handleDownload({ id, kind, candidates }) {
  for (const url of candidates || []) {
    const ext = extensionOf(url, kind);
    if (await attemptDownload(url, `Pinterest/pin_${id}.${ext}`)) {
      bumpCounter();
      return { ok: true, url };
    }
  }
  return { ok: false, error: "direct link kaam nahi kiya" };
}
