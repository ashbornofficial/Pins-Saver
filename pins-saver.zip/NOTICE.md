# Third-party notices

This project bundles the following third-party software:

## mux.js (v6.3.0)
- File: `mux.js` (browser bundle built with esbuild)
- Purpose: converts MPEG-TS video segments to MP4 in the browser
- License: Apache License 2.0 — full text in `third_party/mux.js-LICENSE.txt`
- Source: https://github.com/videojs/mux.js

"Pinterest" is a trademark of Pinterest, Inc. This project is an independent
tool and is not affiliated with, endorsed by, or sponsored by Pinterest.
