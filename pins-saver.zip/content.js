(() => {
  "use strict";

  const CFG = {
    MIN_SIZE: 200,   // isse chhoti image/video ignore (avatars, icons)
    TICK_MS: 400,    // Pinterest SPA hai, isliye har 400ms check
    GAP: 10          // media ke neeche gap (px)
  };

  const ICON =
    '<svg viewBox="0 0 24 24"><path d="M12 3v12m0 0l-4-4m4 4l4-4M4 21h16"/></svg>';

  let bar = null, btn = null, labelEl = null;
  let media = null;
  let state = "idle"; // idle | busy | done | error
  let idleLabel = "Download";
  let rafPending = false;
  let lastPinId = null;
  let pinOpenedAt = 0; // performance.now() jab ye pin khula

  try { performance.setResourceTimingBufferSize(2000); } catch (_) {}

  /* ---------- helpers ---------- */

  const getPinId = () => {
    const m = location.pathname.match(/\/pin\/(?:[^/]*--)?(\d+)/);
    return m ? m[1] : null;
  };

  const isSmallAvatar = (src) => /\/\d{2,3}x\d{2,3}(?:_RS)?\//.test(src);

  // Page par sabse bada pin media dhoondo (video ko priority agar barabar ka ho)
  function findMedia() {
    let bestImg = null, bestImgArea = 0;
    let bestVid = null, bestVidArea = 0;

    for (const v of document.querySelectorAll("video")) {
      const r = v.getBoundingClientRect();
      const a = r.width * r.height;
      if (r.width >= CFG.MIN_SIZE && r.height >= CFG.MIN_SIZE && a > bestVidArea) {
        bestVid = v; bestVidArea = a;
      }
    }
    for (const img of document.images) {
      const src = img.currentSrc || img.src || "";
      if (!/pinimg\.com/.test(src) || isSmallAvatar(src)) continue;
      const r = img.getBoundingClientRect();
      const a = r.width * r.height;
      if (r.width >= CFG.MIN_SIZE && r.height >= CFG.MIN_SIZE && a > bestImgArea) {
        bestImg = img; bestImgArea = a;
      }
    }
    if (bestVid && bestVidArea >= bestImgArea * 0.7) return bestVid;
    return bestImg;
  }

  /* ---------- UI ---------- */

  function createBar() {
    bar = document.createElement("div");
    bar.id = "pinsaver-bar";
    btn = document.createElement("button");
    btn.type = "button";
    btn.innerHTML = ICON + "<span></span>";
    labelEl = btn.querySelector("span");
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      onDownload();
    });
    // Pinterest ke apne click handlers ko trigger hone se roko
    ["mousedown", "mouseup", "pointerdown"].forEach((ev) =>
      bar.addEventListener(ev, (e) => e.stopPropagation())
    );
    bar.appendChild(btn);
    document.documentElement.appendChild(bar);
  }

  function setState(s, text) {
    state = s;
    bar.dataset.state = s;
    btn.disabled = s === "busy";
    labelEl.textContent = text || idleLabel;
  }

  function position() {
    if (!bar || !media || !document.contains(media)) return hide();
    const r = media.getBoundingClientRect();
    if (r.bottom < 40 || r.top > innerHeight - 40) return hide();
    bar.style.display = "block";
    const h = bar.offsetHeight || 44;
    let top = r.bottom + CFG.GAP;
    if (top + h > innerHeight - 8) top = innerHeight - h - 8; // viewport ke andar rakho
    bar.style.left = r.left + r.width / 2 + "px";
    bar.style.top = top + "px";
  }

  function hide() {
    if (bar) bar.style.display = "none";
  }

  function schedulePosition() {
    if (rafPending) return;
    rafPending = true;
    requestAnimationFrame(() => { rafPending = false; position(); });
  }

  /* ---------- URL candidates ---------- */

  function parseSrcset(srcset) {
    if (!srcset) return [];
    return srcset.split(",")
      .map((p) => p.trim().split(/\s+/))
      .filter((p) => p[0])
      .sort((a, b) => (parseFloat(b[1]) || 0) - (parseFloat(a[1]) || 0))
      .map((p) => p[0]);
  }

  // Original quality pehle, phir fallback (background HEAD se check karega)
  function imageCandidates(img) {
    const cur = img.currentSrc || img.src;
    const out = [];
    const m = cur.match(/^(https?:\/\/[^/]*pinimg\.com\/)[^/]+\/(.+)\.(\w+)$/);
    if (m) {
      const exts = [...new Set([m[3], "png", "jpg", "webp", "gif"])];
      for (const e of exts) out.push(`${m[1]}originals/${m[2]}.${e}`);
    }
    out.push(...parseSrcset(img.srcset), cur);
    return [...new Set(out)];
  }

  /* ---------- video source discovery ---------- */

  async function fetchPinJson(id, fieldSet) {
    const data = encodeURIComponent(JSON.stringify({
      options: { id, field_set_key: fieldSet, noCache: true },
      context: {}
    }));
    const url = `${location.origin}/resource/PinResource/get/` +
      `?source_url=${encodeURIComponent("/pin/" + id + "/")}&data=${data}`;
    const r = await fetch(url, {
      credentials: "include",
      headers: {
        Accept: "application/json",
        "X-Requested-With": "XMLHttpRequest",
        "X-Pinterest-AppState": "active"
      }
    });
    if (!r.ok) throw new Error("API " + r.status);
    return r.json();
  }

  function collectVideoFiles(node, acc = [], depth = 0) {
    if (!node || typeof node !== "object" || depth > 14) return acc;
    if (node.video_list && typeof node.video_list === "object") {
      for (const k in node.video_list) {
        const e = node.video_list[k];
        if (e && typeof e.url === "string")
          acc.push({ url: e.url, w: e.width || 0, h: e.height || 0 });
      }
    }
    for (const k in node) {
      const v = node[k];
      if (v && typeof v === "object") collectVideoFiles(v, acc, depth + 1);
    }
    return acc;
  }

  const qualityOf = (f) => {
    if (f.w && f.h) return f.w * f.h;
    const m = f.url.match(/(\d{3,4})[pw]/);
    return m ? parseInt(m[1], 10) : 0;
  };

  // HLS link se MP4 link ka andaaza (fail ho to koi nuksan nahi)
  function hlsToMp4Guesses(u) {
    const base = u.replace(/\.m3u8.*$/, "");
    if (!u.includes("/hls/")) return [];
    return [
      base.replace("/hls/", "/720p/") + ".mp4",
      base.replace("/hls/", "/expMp4/") + "_720w.mp4"
    ];
  }

  // Page ne jo network requests ki hain unme se video URLs (player ne khud m3u8 maanga hoga)
  function perfVideoUrls() {
    const out = [];
    for (const e of performance.getEntriesByType("resource")) {
      if (e.startTime < pinOpenedAt - 500) continue;
      if (/pinimg\.com\/videos\/.+?\.(?:mp4|m3u8)/i.test(e.name)) out.push(e.name);
    }
    return out;
  }

  // Pin page ke HTML me embedded JSON se video URLs
  async function htmlVideoUrls(id) {
    const r = await fetch(`${location.origin}/pin/${id}/`, { credentials: "include" });
    if (!r.ok) return [];
    const text = (await r.text()).replace(/\\u002F/gi, "/").replace(/\\\//g, "/");
    return text.match(/https:\/\/[\w.-]*pinimg\.com\/videos\/[^"'\\\s<>]+?\.(?:mp4|m3u8)/g) || [];
  }

  async function videoSources(id, video) {
    const mp4 = [], hls = [];
    const add = (u) => {
      if (!u) return;
      if (/\.m3u8/i.test(u)) hls.push(u);
      else if (/\.mp4/i.test(u)) mp4.push(u);
    };

    // 1) Pinterest API (alag-alag field sets try karo)
    for (const fs of ["auth_web_main_pin", "unauth_react_main_pin", "detailed"]) {
      try {
        const files = collectVideoFiles(await fetchPinJson(id, fs));
        if (files.length) {
          files.sort((a, b) => qualityOf(b) - qualityOf(a)).forEach((f) => add(f.url));
          break;
        }
      } catch (e) {
        console.warn("[PinSaver] API", fs, "fail:", e.message);
      }
    }

    // 2) Page ne jo load kiya (network entries)
    perfVideoUrls().forEach(add);

    // 3) <video> ka apna http src
    [video.currentSrc, video.src, ...[...video.querySelectorAll("source")].map((s) => s.src)]
      .filter((u) => u && /^https?:/.test(u)).forEach(add);

    // 4) Aakhri koshish: pin page ka HTML
    if (!mp4.length && !hls.length) {
      try { (await htmlVideoUrls(id)).forEach(add); }
      catch (e) { console.warn("[PinSaver] html scan fail:", e.message); }
    }

    // real MP4 pehle, phir HLS se banaye guesses
    const guesses = hls.flatMap(hlsToMp4Guesses);
    return {
      mp4: [...new Set([...mp4, ...guesses])],
      hls: [...new Set(hls)]
    };
  }

  function saveBlob(blob, filename) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.documentElement.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 60000);
  }

  /* ---------- main action ---------- */

  async function onDownload() {
    if (state === "busy" || !media) return;
    const id = getPinId() || String(Date.now());
    const isVideo = media.tagName === "VIDEO";
    setState("busy", "Searching...");
    let ok = false, lastErr = "";
    try {
      if (!isVideo) {
        const res = await chrome.runtime.sendMessage({
          type: "PINSAVER_DOWNLOAD", id, kind: "image", candidates: imageCandidates(media)
        });
        ok = !!(res && res.ok);
        lastErr = (res && res.error) || "";
      } else {
        const src = await videoSources(id, media);
        console.log("[PinSaver] video sources:", src);

        // Step 1: direct MP4
        if (src.mp4.length) {
          setState("busy", "Downloading...");
          const res = await chrome.runtime.sendMessage({
            type: "PINSAVER_DOWNLOAD", id, kind: "video", candidates: src.mp4
          });
          ok = !!(res && res.ok);
        }
        // Step 2: HLS stream -> khud segments download karke MP4 banao
        if (!ok && src.hls.length) {
          for (const u of src.hls.slice(0, 3)) {
            try {
              setState("busy", "Downloading 0%");
              const blob = await window.PinSaverHls.hlsToBlob(u, (p) =>
                setState("busy", `Downloading ${Math.round(p * 100)}%`));
              setState("busy", "Saving...");
              saveBlob(blob, `pin_${id}.mp4`);
              chrome.runtime.sendMessage({ type: "PINSAVER_BUMP" });
              ok = true;
              break;
            } catch (e) {
              lastErr = e.message;
              console.warn("[PinSaver] HLS fail:", u, e);
            }
          }
        }
        if (!ok && !lastErr) lastErr = "video link nahi mila";
      }
    } catch (e) {
      console.error("[PinSaver]", e);
      lastErr = e.message;
    }

    if (ok) setState("done", "Saved ✓");
    else setState("error", "Fail: " + (lastErr || "unknown") + " (F12 > Console)");
    setTimeout(() => { if (bar) setState("idle"); }, 4500);
  }

  /* ---------- SPA watcher ---------- */

  function tick() {
    const pid = getPinId();
    if (pid !== lastPinId) { lastPinId = pid; pinOpenedAt = performance.now(); }
    if (!pid) return hide();               // sirf /pin/... pages par
    const m = findMedia();
    if (!m) return hide();
    media = m;
    if (!bar) createBar();
    idleLabel = m.tagName === "VIDEO" ? "Download Video" : "Download Image";
    if (state === "idle") labelEl.textContent = idleLabel;
    position();
  }

  setInterval(tick, CFG.TICK_MS);
  addEventListener("scroll", schedulePosition, { capture: true, passive: true });
  addEventListener("resize", schedulePosition);
})();
