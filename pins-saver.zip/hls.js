// HLS (.m3u8) stream ko download karke single MP4 blob banata hai.
// TS segments ko mux.js se MP4 me convert karta hai (mux.js = bundled, remote code nahi).
(() => {
  "use strict";
  const root = typeof window !== "undefined" ? window : globalThis;
  const abs = (u, base) => new URL(u, base).href;

  async function getText(url) {
    const r = await fetch(url);
    if (!r.ok) throw new Error("playlist HTTP " + r.status);
    return r.text();
  }

  // Master playlist ho to sabse high-bandwidth variant chuno
  async function getMediaPlaylist(url) {
    let text = await getText(url);
    if (/#EXT-X-STREAM-INF/.test(text)) {
      const lines = text.split(/\r?\n/);
      let best = null, bestBw = -1;
      for (let i = 0; i < lines.length; i++) {
        if (!lines[i].startsWith("#EXT-X-STREAM-INF")) continue;
        const m = lines[i].match(/BANDWIDTH=(\d+)/);
        const bw = m ? parseInt(m[1], 10) : 0;
        const uri = lines.slice(i + 1).find((l) => l && !l.startsWith("#"));
        if (uri && bw > bestBw) { bestBw = bw; best = abs(uri, url); }
      }
      if (!best) throw new Error("variant nahi mila");
      url = best;
      text = await getText(url);
    }
    return { url, text };
  }

  async function fetchAll(urls, onProgress, concurrency = 6) {
    const out = new Array(urls.length);
    let next = 0, done = 0;
    const worker = async () => {
      while (next < urls.length) {
        const k = next++;
        const r = await fetch(urls[k]);
        if (!r.ok) throw new Error("segment HTTP " + r.status);
        out[k] = new Uint8Array(await r.arrayBuffer());
        done++;
        if (onProgress) onProgress(done / urls.length);
      }
    };
    await Promise.all(Array.from({ length: Math.min(concurrency, urls.length) }, worker));
    return out;
  }

  function transmux(chunks) {
    const t = new root.muxjs.mp4.Transmuxer({ keepOriginalTimestamps: true });
    const parts = [];
    let gotInit = false;
    t.on("data", (seg) => {
      if (!gotInit) { gotInit = true; parts.push(seg.initSegment); }
      parts.push(seg.data);
    });
    chunks.forEach((c) => t.push(c));
    t.flush();
    if (!parts.length) throw new Error("conversion fail");
    return parts;
  }

  async function hlsToBlob(m3u8Url, onProgress) {
    const { url, text } = await getMediaPlaylist(m3u8Url);
    if (/#EXT-X-KEY:(?!METHOD=NONE)/.test(text)) throw new Error("stream encrypted hai");

    let mapUrl = null;
    const segs = [];
    for (const line of text.split(/\r?\n/)) {
      if (line.startsWith("#EXT-X-MAP")) {
        const m = line.match(/URI="([^"]+)"/);
        if (m) mapUrl = abs(m[1], url);
      } else if (line && !line.startsWith("#")) {
        segs.push(abs(line, url));
      }
    }
    if (!segs.length) throw new Error("segments nahi mile");

    const chunks = await fetchAll(segs, onProgress);

    if (mapUrl) { // fragmented MP4: init + segments seedha jodo
      const [init] = await fetchAll([mapUrl]);
      return new Blob([init, ...chunks], { type: "video/mp4" });
    }
    if (root.muxjs) { // MPEG-TS -> MP4
      return new Blob(transmux(chunks), { type: "video/mp4" });
    }
    return new Blob(chunks, { type: "video/mp2t" });
  }

  root.PinSaverHls = { hlsToBlob };
})();
