(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);

  /* ---- version ---- */
  $("ver").textContent = "v" + chrome.runtime.getManifest().version;

  /* ---- developer card ---- */
  const d = DEVELOPER;
  $("devName").textContent = d.name;
  $("devRole").textContent = d.role;
  $("devBio").textContent = d.bio;
  $("devBio").hidden = !d.bio;
  $("avatar").textContent = d.name.trim().split(/\s+/).slice(0, 2)
    .map((w) => w[0].toUpperCase()).join("");

  const ICONS = {
    mail: '<path d="M4 6h16v12H4z"/><path d="M4 7l8 6 8-6"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18"/>',
    github: '<path d="M9 19c-4 1.5-4-2-6-2m12 4v-3.5c0-1 .1-1.4-.5-2 2.800-.3 5.500-1.400 5.500-6a4.600 4.600 0 0 0-1.300-3.200 4.200 4.200 0 0 0-.1-3.200s-1.100-.3-3.500 1.300a12 12 0 0 0-6.200 0C6.500 2.800 5.400 3.100 5.400 3.100a4.200 4.200 0 0 0-.1 3.200A4.600 4.600 0 0 0 4 9.500c0 4.600 2.700 5.700 5.500 6-.6.600-.6 1.200-.5 2V21"/>',
    linkedin: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 11v6M8 7.500v.01M12 17v-6m0 3c0-2 1-3 3-3s2 1.500 2 3v3"/>',
    instagram: '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.500" cy="6.500" r=".6"/>',
    twitter: '<path d="M4 4l16 16M20 4L4 20"/>'
  };

  const LINKS = [
    ["email",     "Email",     "mail",      (v) => "mailto:" + v],
    ["website",   "Website",   "globe",     (v) => v],
    ["github",    "GitHub",    "github",    (v) => v],
    ["linkedin",  "LinkedIn",  "linkedin",  (v) => v],
    ["instagram", "Instagram", "instagram", (v) => v],
    ["twitter",   "X",         "twitter",   (v) => v]
  ];

  const links = $("links");
  for (const [key, label, icon, href] of LINKS) {
    if (!d[key]) continue;
    const a = document.createElement("a");
    a.href = href(d[key]);
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.innerHTML = '<svg viewBox="0 0 24 24">' + ICONS[icon] + "</svg>";
    a.appendChild(document.createTextNode(label));
    links.appendChild(a);
  }

  /* ---- counter ---- */
  chrome.storage.local.get({ count: 0 }, ({ count }) => {
    $("count").textContent = count;
  });

  /* ---- current tab status ---- */
  const setStatus = (kind, text) => {
    $("status").dataset.kind = kind;
    $("statusText").textContent = text;
  };
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    let u = null;
    try { u = tab && tab.url ? new URL(tab.url) : null; } catch (_) {}
    if (u && /(^|\.)pinterest\.[a-z.]+$/.test(u.hostname)) {
      if (/\/pin\//.test(u.pathname)) {
        setStatus("ready", "Pin page mil gaya - media ke neeche Download button dekho");
      } else {
        setStatus("pinterest", "Pinterest khula hai - koi pin kholo");
      }
    } else {
      setStatus("idle", "Pinterest.com kholo, phir koi pin open karo");
    }
  });
})();
