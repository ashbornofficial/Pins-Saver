// ======================================================
//  YAHAN APNI DETAILS BHARO (popup me yahi dikhengi)
//  Jo link khali ("") rakhoge wo popup me nahi dikhega.
// ======================================================
const DEVELOPER = {
  name: "Your Name",
  role: "Software Developer",
  bio: "Browser extensions aur web apps banata hoon. Feedback ya bug mile to zaroor batao!",
  email: "you@example.com",
  website: "",
  github: "",
  linkedin: "",
  instagram: "",
  twitter: ""
};
